-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: sigap_db
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resourceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `userId` int NOT NULL,
  `departmentId` int DEFAULT NULL,
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_userId_idx` (`userId`),
  KEY `AuditLog_departmentId_idx` (`departmentId`),
  KEY `AuditLog_createdAt_idx` (`createdAt`),
  CONSTRAINT `AuditLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
INSERT INTO `AuditLog` VALUES (142,'RESET_SYSTEM','System',NULL,'{\"timestamp\":\"2026-04-14T08:46:56.130Z\"}',28,NULL,'::ffff:127.0.0.1','2026-04-14 08:46:56.132'),(143,'CREATE_EVENT','Event','34','{\"after\":{\"id\":34,\"slug\":\"rekrutmen\",\"title\":\"REKRUTMEN\",\"description\":null,\"status\":\"TIDAK_AKTIF\",\"bgType\":\"color\",\"bgValue\":\"#0f172a\",\"profilePhoto\":null,\"profileShape\":\"circle\",\"profileBorderStyle\":\"none\",\"profileBorderWidth\":2,\"profileBgColor\":\"#ffffff\",\"showProfile\":true,\"showCover\":true,\"showTitle\":true,\"showDescription\":true,\"showFooter\":true,\"eventPhoto\":null,\"footerText\":null,\"profileWidth\":80,\"profileHeight\":80,\"coverHeight\":128,\"titleColor\":\"#ffffff\",\"titleFont\":\"Inter\",\"descColor\":\"#ffffff\",\"descFont\":\"Inter\",\"footerColor\":\"#ffffff\",\"footerFont\":\"Inter\",\"buttonShape\":\"rounded\",\"buttonRadius\":12,\"createdAt\":\"2026-04-14T08:47:23.681Z\",\"updatedAt\":\"2026-04-14T08:47:23.681Z\",\"userId\":28}}',28,NULL,'::ffff:127.0.0.1','2026-04-14 08:47:23.689'),(144,'LOGIN_SUCCESS','User','28','{\"username\":\"sigap_admin\",\"method\":\"PASSWORD\"}',28,NULL,'::ffff:127.0.0.1','2026-04-14 13:39:42.334'),(145,'BACKUP_DATABASE','System',NULL,'{\"filename\":\"sigap_backup_2026-04-14T13-44-10.sql\"}',28,NULL,'::ffff:127.0.0.1','2026-04-14 13:44:10.627');
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClickLog`
--

DROP TABLE IF EXISTS `ClickLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClickLog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clickedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `userRole` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ClickLog_clickedAt_idx` (`clickedAt`),
  KEY `ClickLog_linkId_idx` (`linkId`),
  CONSTRAINT `ClickLog_linkId_fkey` FOREIGN KEY (`linkId`) REFERENCES `Link` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClickLog`
--

LOCK TABLES `ClickLog` WRITE;
/*!40000 ALTER TABLE `ClickLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClickLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Event`
--

DROP TABLE IF EXISTS `Event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('AKTIF','TIDAK_AKTIF','ARSIP') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TIDAK_AKTIF',
  `bgType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'color',
  `bgValue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#0f172a',
  `profilePhoto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `showProfile` tinyint(1) NOT NULL DEFAULT '1',
  `eventPhoto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footerText` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `userId` int NOT NULL,
  `profileBgColor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `profileBorderStyle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `profileShape` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'circle',
  `buttonRadius` int DEFAULT '12',
  `buttonShape` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'rounded',
  `coverHeight` int NOT NULL DEFAULT '128',
  `descColor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `descFont` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Inter',
  `footerColor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `footerFont` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Inter',
  `profileBorderWidth` int NOT NULL DEFAULT '2',
  `profileHeight` int NOT NULL DEFAULT '80',
  `profileWidth` int NOT NULL DEFAULT '80',
  `titleColor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `titleFont` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Inter',
  `showCover` tinyint(1) NOT NULL DEFAULT '1',
  `showDescription` tinyint(1) NOT NULL DEFAULT '1',
  `showFooter` tinyint(1) NOT NULL DEFAULT '1',
  `showTitle` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Event_slug_key` (`slug`),
  KEY `Event_userId_idx` (`userId`),
  KEY `Event_slug_idx` (`slug`),
  CONSTRAINT `Event_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Event`
--

LOCK TABLES `Event` WRITE;
/*!40000 ALTER TABLE `Event` DISABLE KEYS */;
INSERT INTO `Event` VALUES (34,'rekrutmen','REKRUTMEN',NULL,'TIDAK_AKTIF','color','#0f172a',NULL,1,NULL,NULL,'2026-04-14 08:47:23.681','2026-04-14 08:47:23.681',28,'#ffffff','none','circle',12,'rounded',128,'#ffffff','Inter','#ffffff','Inter',2,80,80,'#ffffff','Inter',1,1,1,1);
/*!40000 ALTER TABLE `Event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventClickLog`
--

DROP TABLE IF EXISTS `EventClickLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EventClickLog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clickedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `EventClickLog_itemId_idx` (`itemId`),
  KEY `EventClickLog_clickedAt_idx` (`clickedAt`),
  CONSTRAINT `EventClickLog_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `EventItem` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventClickLog`
--

LOCK TABLES `EventClickLog` WRITE;
/*!40000 ALTER TABLE `EventClickLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `EventClickLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventItem`
--

DROP TABLE IF EXISTS `EventItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EventItem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BUTTON',
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `textColor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `order` int NOT NULL DEFAULT '0',
  `clicks` int NOT NULL DEFAULT '0',
  `eventId` int NOT NULL,
  `iconColor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `isActive` tinyint(1) DEFAULT '1',
  `layout` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'icon-left',
  `showLabel` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `EventItem_eventId_idx` (`eventId`),
  CONSTRAINT `EventItem_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventItem`
--

LOCK TABLES `EventItem` WRITE;
/*!40000 ALTER TABLE `EventItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `EventItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Feedback`
--

DROP TABLE IF EXISTS `Feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `userId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `isAnonymous` tinyint(1) NOT NULL DEFAULT '0',
  `imageUrl` text COLLATE utf8mb4_unicode_ci,
  `repliedAt` datetime(3) DEFAULT NULL,
  `repliedById` int DEFAULT NULL,
  `replyMessage` text COLLATE utf8mb4_unicode_ci,
  `replyImageUrl` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `Feedback_userId_idx` (`userId`),
  KEY `Feedback_repliedById_fkey` (`repliedById`),
  CONSTRAINT `Feedback_repliedById_fkey` FOREIGN KEY (`repliedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Feedback_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Feedback`
--

LOCK TABLES `Feedback` WRITE;
/*!40000 ALTER TABLE `Feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `Feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FooterLink`
--

DROP TABLE IF EXISTS `FooterLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FooterLink` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TEXT',
  `logoUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FooterLink`
--

LOCK TABLES `FooterLink` WRITE;
/*!40000 ALTER TABLE `FooterLink` DISABLE KEYS */;
INSERT INTO `FooterLink` VALUES (1,'Portal Berita Sigap','https://news.sigap.go.id','TEXT',NULL,1,1,'2026-04-13 23:40:45.480','2026-04-13 23:40:45.480'),(2,'Aduan Masyarakat','https://lapor.go.id','IMAGE','/uploads/footer/sample-logo.png',2,1,'2026-04-13 23:40:45.480','2026-04-13 23:40:45.480'),(3,'tess','#','TEXT',NULL,2,1,'2026-04-13 23:42:45.613','2026-04-13 23:42:45.613');
/*!40000 ALTER TABLE `FooterLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Link`
--

DROP TABLE IF EXISTS `Link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Link` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clicks` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `category_id` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `visibility` enum('INTERNAL','DEPARTMENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INTERNAL',
  `desc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Link_slug_key` (`slug`),
  KEY `Link_category_id_fkey` (`category_id`),
  KEY `Link_userId_fkey` (`userId`),
  CONSTRAINT `Link_category_id_fkey` FOREIGN KEY (`category_id`) REFERENCES `Category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Link_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Link`
--

LOCK TABLES `Link` WRITE;
/*!40000 ALTER TABLE `Link` DISABLE KEYS */;
/*!40000 ALTER TABLE `Link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `relatedId` int DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Notification_userId_idx` (`userId`),
  KEY `Notification_relatedId_idx` (`relatedId`),
  CONSTRAINT `Notification_relatedId_fkey` FOREIGN KEY (`relatedId`) REFERENCES `Feedback` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Settings`
--

DROP TABLE IF EXISTS `Settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `instansi_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instansi_desc` text COLLATE utf8mb4_unicode_ci,
  `instansi_desc_en` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bg_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `app_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'SIGAP',
  `contact_address` text COLLATE utf8mb4_unicode_ci,
  `contact_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_copyright` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '© 2026 Admin Portal',
  `footer_text` text COLLATE utf8mb4_unicode_ci,
  `footer_text_en` text COLLATE utf8mb4_unicode_ci,
  `footer_mode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'COMPLEX',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Settings`
--

LOCK TABLES `Settings` WRITE;
/*!40000 ALTER TABLE `Settings` DISABLE KEYS */;
INSERT INTO `Settings` VALUES (1,'Rumah Sakit Umum Daerah',NULL,'Melayani dengan hati untuk kesehatan masyarakat.',NULL,NULL,NULL,NULL,'2026-04-13 23:44:03.875','SIGAP','Jakarta, Indonesia','info@sigap.go.id','021-12345678','© 2026 SIGAP Team','Sistem Informasi Galeri & Aplikasi Portal',NULL,'SIMPLE'),(3,'Rumah Sakit Umum Daerah',NULL,'Melayani dengan hati untuk kesehatan masyarakat.',NULL,NULL,NULL,NULL,'2026-04-13 23:40:45.040','SIGAP','Jakarta, Indonesia','info@sigap.go.id','021-12345678','© 2026 SIGAP Team','Sistem Informasi Galeri & Aplikasi Portal',NULL,'COMPLEX');
/*!40000 ALTER TABLE `Settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-',
  `role` enum('ADMIN','ADMIN_EVENT','EMPLOYEE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EMPLOYEE',
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `departmentId` int DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_username_key` (`username`),
  UNIQUE KEY `User_email_key` (`email`),
  KEY `User_departmentId_fkey` (`departmentId`),
  CONSTRAINT `User_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `Category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (28,'sigap_admin','$2b$10$Sm4.Si977J/unS4u0D2mC.ZzgH6L5jPvNMWO0DwSLZhFbX.ysZm46','Administrator Utama','ADMIN',NULL,'2026-04-13 23:40:32.080','2026-04-14 13:39:41.960',NULL,'admin@sigap.go.id','ca74aefe-f0c3-480e-b8df-e09a0a6fe24f');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('22e2e321-1598-4950-a101-a6e3ff92d884','e1f6fa44d8f8997e9013edaafd096a54e3a36bd24f8856625cd99d3b85d7d0c3','2026-04-11 16:11:22.071','20260411131843_role_visibility_email_update',NULL,NULL,'2026-04-11 16:11:21.397',1),('3fe37403-ed5f-4f6f-8a53-754342b7c913','8f65f96172a7e6412824c49b5f865652446d683384e129e9816ced44b3cfda03','2026-04-11 16:11:21.393','20260308104954_link_auto_translate',NULL,NULL,'2026-04-11 16:11:21.331',1),('694d48bb-40f2-44f6-aab0-4ff6d533128c','8ee1704a60c3bfb962262d6f267ec422dcc3bf935fddf39c1c09694208caab92','2026-04-11 16:11:21.328','20260308102245_category_auto_translate',NULL,NULL,'2026-04-11 16:11:21.283',1),('ee1939bd-5827-48e7-b3ef-7c6a380d08c6','41e393ab8630cfffe319bdd8e5415b185be0c362b0c81db927c7790c52518c2c','2026-04-11 16:11:21.280','20260216101000_init_ulang_total',NULL,NULL,'2026-04-11 16:11:20.898',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-14 20:44:22
